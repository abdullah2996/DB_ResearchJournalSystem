-- Table 1: Researcher
CREATE TABLE Researcher (
    ResearcherID INT PRIMARY KEY,
    FullName VARCHAR(100),
    Email VARCHAR(100),
    Affiliation VARCHAR(100),
    ORCID VARCHAR(20),
    Role VARCHAR(20)
);

INSERT INTO Researcher (ResearcherID, FullName, Email, Affiliation, ORCID, Role) VALUES
(1, 'Ayesha Khan', 'ayesha@nu.edu.pk', 'NUST', '0000-0001-01', 'Author'),
(2, 'Bilal Ahmed', 'bilal@uet.edu.pk', 'UET Lahore', '0000-0002-02', 'Reviewer'),
(3, 'Fatima Zahra', 'fatima@iba.edu.pk', 'IBA Karachi', '0000-0003-03', 'Author'),
(4, 'Daniyal Siddiqui', 'daniyal@lums.edu.pk', 'LUMS', '0000-0004-04', 'Both'),
(5, 'Hafsa Javed', 'hafsa@fast.edu.pk', 'FAST Islamabad', '0000-0005-05', 'Reviewer'),
(6, 'Salman Tariq', 'salman@nu.edu.pk', 'NUST', '0000-0006-06', 'Author'),
(7, 'Laiba Farooq', 'laiba@uet.edu.pk', 'UET Lahore', '0000-0007-07', 'Both'),
(8, 'Usman Ali', 'usman@iba.edu.pk', 'IBA Karachi', '0000-0008-08', 'Author'),
(9, 'Zainab Noor', 'zainab@lums.edu.pk', 'LUMS', '0000-0009-09', 'Reviewer'),
(10, 'Imran Shah', 'imran@comsats.edu.pk', 'COMSATS Islamabad', '0000-0010-10', 'Editor');

-- Table 2: Paper
CREATE TABLE Paper (
    PaperID INT PRIMARY KEY,
    Title VARCHAR(200),
    Abstract TEXT,
    SubmissionDate DATE,
    FilePath VARCHAR(255),
    Status VARCHAR(50)
);

INSERT INTO Paper (PaperID, Title, Abstract, SubmissionDate, FilePath, Status) VALUES
(101, 'Urdu NLP Models', 'Language Processing...', '2025-01-05', '/papers/nlp_urdu.pdf', 'Submitted'),
(102, 'Blockchain for Govt', 'Transparent systems...', '2025-01-08', '/papers/block_gov.pdf', 'Under Rev'),
(103, 'Vision AI in Medicine', 'Diagnosis support...', '2025-01-10', '/paers/med_vision.pdf', 'Accepted'),
(104, 'Smart Traffic IoT', 'Smart transport...', '2025-01-13', '/papers/iot_traffic.pdf', 'Submitted'),
(105, 'Fintech Risk Models', 'Risk prediction...', '2025-01-15', '/papers/fintech.pdf', 'Draft'),
(106, 'AI Chatbots for Urdu', 'Conversional AI...', '2025-01-18', '/papers/chatbot.pdf', 'Published'),
(107, 'Crop Monitoring Drones', 'Precision farming...', '2025-01-20', '/papers/drones_crop.pdf', 'Submitted'),
(108, 'Quantum Cryptography', 'Security enhancements', '2025-01-22', '/papers/quantum_sec.pdf', 'Submitted'),
(109, 'Machine Translation (Urdu)', 'Multilingual NLP...', '2025-01-25', '/papers/mt_urdu.pdf', 'Under Rev'),
(110, 'Sentiment Analysis in Urdu', 'Opinion mining...', '2025-01-27', '/papers/sentiment.pdf', 'Submitted');

-- Table 3: Journal
CREATE TABLE Journal (
    JournalID INT PRIMARY KEY,
    Name VARCHAR(100),
    ISSN VARCHAR(20),
    Scope VARCHAR(200),
    Publisher VARCHAR(100)
);

INSERT INTO Journal (JournalID, Name, ISSN, Scope, Publisher) VALUES
(1, 'Pakistan Journal of AI', '2345-6781', 'Artificial Intelligence', 'NUST'),
(2, 'Islamic Computing Review', '2345-6782', 'Islamic Tech Ethics', 'PUCIT'),
(3, 'Journal of Data Science', '2345-6783', 'Data Science and Analytics', 'LUMS'),
(4, 'QuantumTech Pakistan', '2345-6784', 'Quantum Research', 'FAST'),
(5, 'IoT and Sensor Networks', '2345-6785', 'IoT and Sensors', 'GIKI'),
(6, 'Cyber Security Today', '2345-6786', 'Cybersecurity', 'COMSATS'),
(7, 'Blockchain Ledger PK', '2345-6787', 'Blockchain Systems', 'IBA Karachi'),
(8, 'Big Data Review', '2345-6788', 'Big Data Technologies', 'QAU'),
(9, 'Smart Health Journal', '2345-6789', 'AI in Healthcare', 'UET Lahore'),
(10, 'NLP Research Notes', '2345-6790', 'Natural Language Processing', 'NUML');


-- Table 4: Submission
CREATE TABLE Submission (
    SubmissionID INT PRIMARY KEY,
    PaperID INT,
    JournalID INT,
    EditorID INT,
    SubmissionDate DATE,
    Status VARCHAR(50),
    FOREIGN KEY (PaperID) REFERENCES Paper(PaperID),
    FOREIGN KEY (JournalID) REFERENCES Journal(JournalID),
    FOREIGN KEY (EditorID) REFERENCES Researcher(ResearcherID)
);

INSERT INTO Submission (SubmissionID, PaperID, JournalID, EditorID, SubmissionDate, Status) VALUES
(1, 101, 1, 10, '2025-01-05', 'Under Review'),
(2, 102, 2, 4, '2025-01-08', 'Under Review'),
(3, 103, 3, 10, '2025-01-10', 'Accepted'),
(4, 104, 1, 10, '2025-01-13', 'Under Review'),
(5, 105, 2, 4, '2025-01-15', 'Draft'),
(6, 106, 1, 10, '2025-01-18', 'Published'),
(7, 107, 3, 10, '2025-01-20', 'Under Review'),
(8, 108, 2, 4, '2025-01-22', 'Under Review'),
(9, 109, 1, 10, '2025-01-25', 'Under Review'),
(10, 110, 1, 10, '2025-01-27', 'Under Review');

-- Table 5: Reviewer
CREATE TABLE Reviewer (
    ReviewerID INT PRIMARY KEY,
    ExpertiseArea VARCHAR(100),
    AssignedDate DATE,
    FOREIGN KEY (ReviewerID) REFERENCES Researcher(ResearcherID)
);

INSERT INTO Reviewer (ReviewerID, ExpertiseArea, AssignedDate) VALUES
(2, 'Networks', '2025-01-10'),
(4, 'AI', '2025-02-14'),
(5, 'Databases', '2025-03-22'),
(7, 'Machine Learning', '2025-04-01'),
(9, 'Cybersecurity', '2025-05-18');

-- Table 6: Review
CREATE TABLE Review (
    ReviewID INT PRIMARY KEY,
    SubmissionID INT,
    ReviewerID INT,
    Comments TEXT,
    Score INT,
    ReviewDate DATE,
    FOREIGN KEY (SubmissionID) REFERENCES Submission(SubmissionID),
    FOREIGN KEY (ReviewerID) REFERENCES Reviewer(ReviewerID)
);

INSERT INTO Review (ReviewID, SubmissionID, ReviewerID, Comments, Score, ReviewDate) VALUES
(1, 1, 2, 'Excellent research on Urdu NLP.', 9, '2025-01-07'),
(2, 1, 4, 'Needs more citations.', 7, '2025-01-08'),
(3, 2, 5, 'Solid technical foundation.', 8, '2025-01-10'),
(4, 3, 7, 'Well-written, needs proofreading.', 7, '2025-01-11'),
(5, 4, 9, 'Smart implementation of IoT.', 9, '2025-01-14'),
(6, 5, 2, 'Paper is still in draft.', 5, '2025-01-16'),
(7, 6, 5, 'Ready for publication.', 10, '2025-01-20'),
(8, 7, 4, 'Great use of drone data.', 8, '2025-01-21'),
(9, 8, 7, 'Complex quantum concepts simplified.', 9, '2025-01-23'),
(10, 9, 9, 'Needs more Urdu translation eval.', 7, '2025-01-26');

-- Table 7: RevisionHistory
CREATE TABLE RevisionHistory (
    RevisionID INT PRIMARY KEY,
    SubmissionID INT,
    RevisionDate DATE,
    RevisedBy INT,
    Notes TEXT,
    FOREIGN KEY (SubmissionID) REFERENCES Submission(SubmissionID),
    FOREIGN KEY (RevisedBy) REFERENCES Researcher(ResearcherID)
);

INSERT INTO RevisionHistory (RevisionID, SubmissionID, RevisionDate, RevisedBy, Notes) VALUES
(1, 1, '2025-01-15', 1, 'Added recent citations'),
(2, 4, '2025-01-20', 3, 'Updated IoT sensor section'),
(3, 7, '2025-01-25', 6, 'Added crop comparison data'),
(4, 9, '2025-01-29', 8, 'Included Urdu benchmarks'),
(5, 10, '2025-01-30', 1, 'Grammar fix'),
(6, 2, '2025-02-01', 3, 'Minor formatting changes'),
(7, 8, '2025-02-02', 6, 'Refined quantum key section'),
(8, 5, '2025-02-03', 4, 'Completed intro and methods'),
(9, 3, '2025-02-05', 1, 'Added figure captions'),
(10, 6, '2025-02-06', 8, 'Published as-is');

-- Table 8: ReviewDecision
CREATE TABLE ReviewDecision (
    DecisionID INT PRIMARY KEY,
    SubmissionID INT,
    FinalDecision VARCHAR(20),
    DecisionDate DATE,
    Comments TEXT,
    FOREIGN KEY (SubmissionID) REFERENCES Submission(SubmissionID)
);

INSERT INTO ReviewDecision (DecisionID, SubmissionID, FinalDecision, DecisionDate, Comments) VALUES
(1, 1, 'Revise', '2025-01-09', 'Add more recent references'),
(2, 2, 'Accept', '2025-01-11', 'Ready to publish'),
(3, 3, 'Accept', '2025-01-12', 'Accepted with minor edits'),
(4, 4, 'Revise', '2025-01-15', 'Improve sensor explanation'),
(5, 5, 'Pending', '2025-01-17', 'Draft not evaluated yet'),
(6, 6, 'Accept', '2025-01-20', 'Published'),
(7, 7, 'Revise', '2025-01-22', 'Include drone comparison chart'),
(8, 8, 'Accept', '2025-01-24', 'Well-structured submission'),
(9, 9, 'Revise', '2025-01-27', 'Needs user study'),
(10, 10, 'Pending', '2025-01-28', 'Awaiting reviews');

-- Table 9: Editor
CREATE TABLE Editor (
    EditorID INT PRIMARY KEY,
    AssignedJournalID INT,
    JoinDate DATE,
    FOREIGN KEY (EditorID) REFERENCES Researcher(ResearcherID),
    FOREIGN KEY (AssignedJournalID) REFERENCES Journal(JournalID)
);

INSERT INTO Editor (EditorID, AssignedJournalID, JoinDate) VALUES
(10, 1, '2024-06-01'),
(4, 2, '2024-07-15');

-- Table 10: Conference
CREATE TABLE Conference (
    ConferenceID INT PRIMARY KEY,
    Name VARCHAR(100),
    Venue VARCHAR(100),
    Date DATE,
    OrganizedBy VARCHAR(100)
);

INSERT INTO Conference (ConferenceID, Name, Venue, Date, OrganizedBy) VALUES
(1, 'Pak AI Summit', 'Islamabad', '2024-04-10', 'NUST'),
(2, 'TechVision 2024', 'Lahore', '2024-05-15', 'UET Lahore'),
(3, 'QuantumCon PK', 'Karachi', '2024-06-20', 'IBA Karachi'),
(4, 'CyberSecConf', 'Peshawar', '2024-07-25', 'FAST'),
(5, 'IoT Expo', 'Faisalabad', '2024-08-30', 'COMSATS'),
(6, 'DataSci Forum', 'Multan', '2024-09-05', 'LUMS'),
(7, 'Blockchain Meet', 'Quetta', '2024-10-10', 'IBA'),
(8, 'AgriTech Summit', 'Rawalpindi', '2024-11-15', 'UAF'),
(9, 'Urdu NLP Meet', 'Islamabad', '2024-12-20', 'FAST'),
(10, 'AI Ethics Workshop', 'Lahore', '2025-01-25', 'UET');

-- Table 11: Topic
CREATE TABLE Topic (P
    TopicID INT PRIMARY KEY,
    Name VARCHAR(100),
    Description TEXT
);

INSERT INTO Topic (TopicID, Name, Description) VALUES
(1, 'Artificial Intelligence', 'AI & Machine Learning'),
(2, 'Internet of Things', 'IoT devices & applications'),
(3, 'Cybersecurity', 'Digital security practices'),
(4, 'Natural Language Processing', 'Urdu language processing'),
(5, 'Blockchain', 'Distributed ledger tech'),
(6, 'Data Science', 'Big data & analytics'),
(7, 'Quantum Computing', 'Quantum logic and hardware'),
(8, 'Computer Vision', 'Image/video processing'),
(9, 'Agriculture Tech', 'Farming and automation'),
(10, 'E-Governance', 'Digital public services');

-- Table 12: Notification
CREATE TABLE Notification (
    NotificationID INT PRIMARY KEY,
    UserID INT,
    Message TEXT,
    DateSent DATE,
    Type VARCHAR(20),
    FOREIGN KEY (UserID) REFERENCES Researcher(ResearcherID)
);

INSERT INTO Notification (NotificationID, UserID, Message, DateSent, Type) VALUES
(1, 1, 'Your paper requires revision.', '2025-01-09', 'Email'),
(2, 3, 'Paper accepted for publication.', '2025-01-12', 'System'),
(3, 4, 'Assigned as reviewer for Paper 104.', '2025-01-14', 'Email'),
(4, 5, 'Submission 106 is now published.', '2025-01-20', 'System'),
(5, 6, 'Paper revised successfully.', '2025-01-21', 'Email'),
(6, 7, 'Submission status updated.', '2025-01-23', 'System'),
(7, 8, 'Feedback required for revision.', '2025-01-26', 'Email'),
(8, 9, 'New review assignment available.', '2025-01-27', 'Email'),
(9, 2, 'Review deadline is approaching.', '2025-01-28', 'System'),
(10, 10, 'New submission to review.', '2025-01-29', 'Email');

-- Table 13: Authorship
CREATE TABLE Authorship (
    PaperID INT,
    ResearcherID INT,
    ContributionPercent INT,
    AuthorOrder INT,
    PRIMARY KEY (PaperID, ResearcherID),
    FOREIGN KEY (PaperID) REFERENCES Paper(PaperID),
    FOREIGN KEY (ResearcherID) REFERENCES Researcher(ResearcherID)
);

INSERT INTO Authorship (PaperID, ResearcherID, ContributionPercent, AuthorOrder) VALUES
(101, 1, 60, 1),
(101, 3, 40, 2),
(102, 4, 100, 1),
(103, 6, 100, 1),
(104, 1, 50, 1),
(104, 8, 50, 2),
(105, 6, 100, 1),
(106, 3, 100, 1),
(107, 4, 100, 1),
(108, 8, 100, 1);

-- Table 14: PaperTopic
CREATE TABLE PaperTopic (
    PaperID INT,
    TopicID INT,
    PRIMARY KEY (PaperID, TopicID),
    FOREIGN KEY (PaperID) REFERENCES Paper(PaperID),
    FOREIGN KEY (TopicID) REFERENCES Topic(TopicID)
);

INSERT INTO PaperTopic (PaperID, TopicID) VALUES
(101, 4),
(102, 5),
(103, 8),
(104, 2),
(105, 6),
(106, 4),
(107, 9),
(108, 7),
(109, 4),
(110, 4);
