
-- INSERT: Add a new Researcher
INSERT INTO Researcher (ResearcherID, FullName, Email, Affiliation, ORCID, Role)
VALUES (11, 'Noman Aslam', 'noman@uet.edu.pk', 'UET Lahore', '0000-0011-11', 'Author');

-- SELECT: Retrieve all papers submitted by 'Ayesha Khan'
SELECT p.*
FROM Paper p
JOIN Authorship a ON p.PaperID = a.PaperID
JOIN Researcher r ON a.ResearcherID = r.ResearcherID
WHERE r.FullName = 'Ayesha Khan';

-- UPDATE: Change the status of a submission
UPDATE Submission
SET Status = 'Accepted'
WHERE SubmissionID = 1;

-- DELETE: Remove a notification by ID
DELETE FROM Notification
WHERE NotificationID = 5;